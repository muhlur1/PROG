public class PrintProduct {

    public void printTotalSales(Product product) {
        System.out.println("Total Products Sold: " + product.GetTotalProductsSold());
    }

    public void printAverageSales(Product product) {
        System.out.printf("Average Products Sold per Product: %.2f\n", product.GetAverageProductSold());
    }

    public void printMostPopularProduct(Product product) {
        System.out.println("Most Popular Product: " + product.GetMostPopularProduct());
    }
}
