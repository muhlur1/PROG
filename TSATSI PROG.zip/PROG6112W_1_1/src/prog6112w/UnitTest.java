import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ProductTest {

    String[] products = {"Mattress A", "Mattress B", "Mattress C"};
    int[][] sales = {
        {30, 25, 40},
        {20, 35, 25},
        {50, 45, 30}
    };

    @Test
    public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
        Product product = new Product(products, sales);
        int expectedTotal = 30 + 25 + 40 + 20 + 35 + 25 + 50 + 45 + 30;
        assertEquals(expectedTotal, product.GetTotalProductsSold());
    }

    @Test
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        Product product = new Product(products, sales);
        int total = 30 + 25 + 40 + 20 + 35 + 25 + 50 + 45 + 30;
        double expectedAverage = (double) total / products.length;
        assertEquals(expectedAverage, product.GetAverageProductSold(), 0.0001);
    }
}
