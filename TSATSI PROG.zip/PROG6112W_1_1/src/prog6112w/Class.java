public class Product implements IProduct {
    private String[] productNames;
    private int[][] sales; // sales[product][month]

    public Product(String[] productNames, int[][] sales) {
        this.productNames = productNames;
        this.sales = sales;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
        }
        return total;
    }

    @Override
    public double GetAverageProductSold() {
        int total = GetTotalProductsSold();
        int productCount = productNames.length;
        return (double) total / productCount;
    }

    @Override
    public String GetMostPopularProduct() {
        int maxSales = 0;
        int popularIndex = 0;

        for (int i = 0; i < sales.length; i++) {
            int productSales = 0;
            for (int j = 0; j < sales[i].length; j++) {
                productSales += sales[i][j];
            }
            if (productSales > maxSales) {
                maxSales = productSales;
                popularIndex = i;
            }
        }
        return productNames[popularIndex];
    }
}
